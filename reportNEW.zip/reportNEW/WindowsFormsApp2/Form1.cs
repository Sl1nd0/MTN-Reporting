﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;

//using S22.Imap;


namespace WindowsFormsApp2
{
    

    public partial class Form1 : Form
    {
        static Form1 f;

        string outputString = "";
        string outputString2 = "";
        string headers = " ";
        int clicked = 0;

        public Form1()
        {
            InitializeComponent();
            f = this;
            listBox1.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
             SqlConnection connection = new SqlConnection();
            clicked = 1;
            connection.ConnectionString = "Data Source = 10.211.110.133\\MDPAGINST11A; Initial Catalog = SCEXPERT; User ID = apexUser; Password = ap3x-rts";
           // connection.ConnectionString = "Data Source = LAPTOP - FO1LJURE\\SQLEXPRESS; Initial Catalog = ordersDB; User ID = LAPTOP-FO1LJURE\\Silindokuhle";

            string myQuery2 = " SELECT * FROM POSTCOMMENTS ";

            SqlCommand command = new SqlCommand();

            string myQuery = "SELECT  OUTBOUNDORHEADER.ORDERID ,";
            myQuery += " OUTBOUNDORHEADER.HOSTORDERID, ";
            myQuery += " OUTBOUNDORHEADER.REFERENCEORD, ";
            myQuery += " OUTBOUNDORHEADER.TARGETCOMPANY , ";
            myQuery += " OUTBOUNDORHEADER.ORDERTYPE  , ";
            myQuery += " OUTBOUNDORHEADER.STATUS ,";
            myQuery += " OUTBOUNDORHEADER.CREATEDATE ,";
            myQuery += " OUTBOUNDORHEADER.EDITDATE ,";
            myQuery += " OUTBOUNDORHEADER.CUSTOMERNAME, OUTBOUNDORHEADER.HAZCLASS, ";
            myQuery += " OUTBOUNDORDETAIL.SKU , OUTBOUNDORDETAIL.QTYORIGINAL /* remv*/";
            myQuery += " FROM OUTBOUNDORHEADER LEFT OUTER JOIN OUTBOUNDORDETAIL ON OUTBOUNDORHEADER.ORDERID = OUTBOUNDORDETAIL.ORDERID ";
            myQuery += " WHERE STATUS IN('NEW', 'PLANNED', 'RELEASED', 'PICKED', 'PACKED') AND OUTBOUNDORHEADER.HAZCLASS LIKE '%311%' AND CREATEDATE<DATEADD(DAY, -2, GETDATE()) ";
            myQuery += " AND(OUTBOUNDORHEADER.SHIPMENTSENT is null OR OUTBOUNDORHEADER.SHIPMENTSENT = 0) ";
            // myQuery += " ";
            myQuery += " ORDER BY CREATEDATE ASC ";

            command.Connection = connection;
            command.CommandText = myQuery;
            command.CommandType = CommandType.Text;
            string myData = "";

            try
            {
                 
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                int j = 0;
                DataTable schemaTable = reader.GetSchemaTable();
                

                foreach (DataRow row in schemaTable.Rows)
                {
                    while (reader.Read())
                    {
                        int i = 0;
                        while (i < reader.FieldCount)
                        {
                            if (i < 13)
                            {
                                outputString += reader[i].ToString() + "\t";
                                outputString2 += reader[i].ToString() + ",";
                                i++;
                            }
                            else
                            {
                                outputString += reader[i].ToString() + "\n";
                                outputString2 += reader[i].ToString() + "\n";
                                i++;
                            }
                            
                        }
                        //MessageBox.Show(reader.FieldCount.ToString());

                        listBox1.Items.Add(outputString);
                        outputString = "";
                        /*
                        outputString2 += outputString + "\n";
                        outputString = "";
                        this.listBox1.Items.Add(outputString2); */
                    }

                }

                reader.Close();
                string name1 = (DateTime.Today).ToString() + "text.csv";

                MessageBox.Show(name1 + " TTT ");

                // string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "MORNING CHECKS", "text.csv");
                //string path = Path.Combine(filePath, "\\);
                //filePath = filePath + "\\";
                string filePath = "text.csv";

                StreamWriter sw1 = new StreamWriter(filePath, true);
               // sw1.WriteLine(Head1);
                sw1.WriteLine(outputString2);
                sw1.Close();
            }
            catch
            {
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(0, 128, 255);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (clicked == 1)
            {
                string name1 = (DateTime.Today).ToString() + "text.csv";

                MessageBox.Show(name1 + " TTT ");

                // string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "MORNING CHECKS", "text.csv");
                //string path = Path.Combine(filePath, "\\);
                //filePath = filePath + "\\";
                string filePath = "text.csv";

                StreamWriter sw1 = new StreamWriter(filePath, true);

                string Head1 = "ORDERID, HOSTORDERID, REFERENCEORD, TARGETCOMPANY, ORDERTYPE, STATUS, CREATEDATE, EDITDATE, CUSTOMERNAME, HAZCLASS, SKU, QTYORIGINAL, QTYPICKED, SHIPMENTSENT";
                //2104632_1   875624  8441389 48580   INTTRFNWH RELEASED    2019 - 04 - 04 00:00:00.000 2019 - 04 - 04 12:04:37.000 MTN Store -Brooklyn(SC)   311WAREHOUSE    7294512 5.0000  0.0000  0
                sw1.WriteLine(Head1);
                sw1.WriteLine(outputString2);
                sw1.Close();
               // System.IO.File.Move("text.csv", "..//..//..//..//..//..//..//MY_WEB//text.csv");
                clicked = 2;
                MessageBox.Show("REPORT GENERATED.", "OUTPUT");

            }
            else if (clicked == 2) {

               MessageBox.Show("REPORT ALREADY GENERATED!!", "OUTPUT", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
               MessageBox.Show("POPULATE THE LISTBOX FIRST BEFORE GENERATING A REPORT!!!", "OUTPUT", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }
    }
}
